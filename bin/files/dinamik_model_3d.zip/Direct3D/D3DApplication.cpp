//-----------------------------------------------------------------------------------
#include "MRCD9.H"


LPDIRECT3D9                 D3D          = NULL;	//������� ������   
LPDIRECT3DDEVICE9           D3DDevice    = NULL;	//������ ����������

CUNIT* Model3D = new CUNIT;

//-----------------------------------------------------------------------------------
//������������� �������� �����
HRESULT InitObjects()
{
	HRESULT hRet = Model3D->CreateModelFF("pauk_run.bma", D3DDevice);	
	if (FAILED(hRet)) {return hRet;};

	return S_OK;
};

//-----------------------------------------------------------------------------------
//�������� ��������
void DeleteObject()
{
	if (Model3D != NULL)
		Model3D->Release();

	if( D3DDevice != NULL) 
        D3DDevice->Release();

    if( D3D != NULL)
        D3D->Release();
};
//-----------------------------------------------------------------------------------
//���������
void Rendering()
{
	if(D3DDevice == NULL)        
        return;

	//������
	D3DXMATRIX matView;
	D3DXMatrixLookAtLH(&matView, &D3DXVECTOR3(500, 500, 500), &D3DXVECTOR3(0, 0, 0), &D3DXVECTOR3(0.0f, 0.0f, 1.0f));
	D3DDevice->SetTransform(D3DTS_VIEW, &matView);

	if (Model3D->rotate<=359) {Model3D->rotate+=1;}
	else {Model3D->rotate = 0;};

	Model3D->Play();

	D3DDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(200,200,200), 1.0f, 0 );
	D3DDevice->BeginScene();
	
	Model3D->Present();

	D3DDevice->EndScene();       
	D3DDevice->Present( NULL, NULL, 0, NULL );
};

//-----------------------------------------------------------------------------------
LRESULT CALLBACK MainWinProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
switch(msg)
  {
    case WM_DESTROY:
    {
	  DeleteObject();
      PostQuitMessage(0);
      return(0);
    }
  }
return DefWindowProc(hwnd, msg, wparam, lparam);
}

//-----------------------------------------------------------------------------------
int WINAPI WinMain( HINSTANCE hinstance, HINSTANCE hprevinstance, LPSTR lpcmdline, int ncmdshow)
{
MSG msg;
HWND hwnd = InitMainForm(hinstance, MainWinProc, "D3D", 800, 600);

if( SUCCEEDED( InitD3D ( &D3D, &D3DDevice, hwnd, TRUE, 800, 600 ) ) )
{
 if( SUCCEEDED(InitObjects() ))
 {
	ShowWindow( hwnd, SW_SHOWDEFAULT );
	UpdateWindow( hwnd );
	ZeroMemory( &msg, sizeof(msg));
	while( msg.message!=WM_QUIT)
	{
		if(PeekMessage( &msg, NULL,0,0,PM_REMOVE ))
		{
			TranslateMessage( &msg );
			DispatchMessage( &msg );
		}
		else
		{Rendering();};
	};
 };
};
return 0;
}
//-----------------------------------------------------------------------------------