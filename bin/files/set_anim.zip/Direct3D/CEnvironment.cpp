#include "CEnvironment.h" 

//---------------------------------------------------------------------------
CENVIRONMENT::CENVIRONMENT()
{
	this->scale = 1.0f;
	this->rrlight = RR_LIGHTOFF;
	this->Place.x = 0.0f;
	this->Place.y = 0.0f;
	this->Place.z = 0.0f;
	this->angx = 0.0f;
	this->angy = 0.0f;
	this->angz = 0.0f;
}

CENVIRONMENT::CENVIRONMENT(float _scale, _RRFLAG _rrlight, CUSTOMVERTEX* place)
{
	this->scale = _scale;
	this->rrlight = _rrlight;
	if (place == NULL) 
	{
		this->Place.x = 0.0f;
		this->Place.y = 0.0f;
		this->Place.z = 0.0f;	
	}
	else
	{this->Place = *place;};
}

void CENVIRONMENT::Release()
{
	if( this->Texture1 != NULL) 
        this->Texture1->Release();

	if( this->BufferVershin != NULL) 
        this->BufferVershin->Release();
}

HRESULT CENVIRONMENT::CreateModelFF(char* passfile, LPDIRECT3DDEVICE9 Device)
{
		//��������� ��������
        this->Mesh.LoadModelFF(passfile);
		
		//�������� ������ �� ������
		this->D3DDevice=Device;
		//������� � ��������� ����� ������
		HRESULT hRet = D3DDevice->CreateVertexBuffer(this->Mesh.kol_vertex*sizeof(CUSTOMVERTEX), 0, D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX1,
						  D3DPOOL_DEFAULT, &BufferVershin, NULL);
		if (FAILED(hRet)){return hRet;};

		hRet = this->ReBuf();
		if (FAILED(hRet)){return hRet;};

		//������� ��������
		hRet = D3DXCreateTextureFromFile(D3DDevice, this->Mesh.texture_pass,&Texture1);
		if (FAILED(hRet)){return hRet;};
		
		return S_OK;
}

HRESULT CENVIRONMENT::Present()
{
	//�������������
	D3DXMATRIX MatrixWorldX,MatrixWorldY, MatrixWorldZ, Buf,Buf3, Buf4, Buf5, MatrixWorld, TransMatrix;
	
	D3DXMatrixRotationX( &MatrixWorldX,  D3DXToRadian(this->angx));
	D3DXMatrixRotationY( &MatrixWorldY,  D3DXToRadian(this->angy));
	D3DXMatrixTranslation(&TransMatrix, this->Place.x, this->Place.y, this->Place.z);
	D3DXMatrixMultiply(&Buf, &MatrixWorldX, &MatrixWorldY);
	D3DXMatrixRotationZ( &MatrixWorldZ,  D3DXToRadian(this->angz) );
	D3DXMatrixMultiply(&Buf3, &Buf,  &MatrixWorldZ);
	D3DXMatrixScaling(&Buf5, this->scale, this->scale, this->scale);
	D3DXMatrixMultiply(&Buf4,&Buf3, &Buf5);
	D3DXMatrixMultiply(&MatrixWorld,&Buf4,&TransMatrix );
	HRESULT hRet = D3DDevice->SetTransform(D3DTS_WORLD, &MatrixWorld);
	if (FAILED(hRet)){return hRet;};
	
	//����� �����
	hRet = D3DDevice->SetRenderState(D3DRS_CULLMODE,         D3DCULL_CCW);
	if (FAILED(hRet)){return hRet;};
    hRet = D3DDevice->SetStreamSource( 0,this->BufferVershin, 0, sizeof(CUSTOMVERTEX) );
	if (FAILED(hRet)){return hRet;};
    hRet = D3DDevice->SetFVF( D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX1 );
	if (FAILED(hRet)){return hRet;};

	//���������������
    hRet = D3DDevice->SetTexture(0, this->Texture1);
	if (FAILED(hRet)){return hRet;};
	//���������� ����� ������ �� ������
	if (this->rrlight==RR_LIGHTOFF)
	{
		hRet = D3DDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTA_TEXTURE);
		if (FAILED(hRet)){return hRet;};
	}
	else
	{
		hRet = D3DDevice->SetTextureStageState (0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
		if (FAILED(hRet)){return hRet;};
		hRet = D3DDevice->SetTextureStageState (0, D3DTSS_COLOROP, D3DTOP_MODULATE);
		if (FAILED(hRet)){return hRet;};
	};
	
	//����������
	hRet = D3DDevice->DrawPrimitive(D3DPT_TRIANGLELIST, 0, this->Mesh.kol_vertex /3);
	if (FAILED(hRet)){return hRet;};

	return S_OK;
}

HRESULT CENVIRONMENT::ReBuf()
{
	VOID* pBV;
    HRESULT hRet = BufferVershin->Lock( 0, this->Mesh.kol_vertex*sizeof(CUSTOMVERTEX), (void**)&pBV, 0 );
	if (FAILED(hRet)){return hRet;};
    memcpy( pBV, this->Mesh.Vertex, this->Mesh.kol_vertex*sizeof(CUSTOMVERTEX) );
    hRet = BufferVershin->Unlock();
	if (FAILED(hRet)){return hRet;};

	return S_OK;
}
//---------------------------------------------------------------------------