#include "CVertex.h"

//---------------------------------------------------------------------------

CUSTOMVERTEX::CUSTOMVERTEX()
{
	this->x = 0.0f;
	this->y = 0.0f;
	this->z = 0.0f;
	this->nx = 0.0f;
	this->ny = 0.0f;
	this->nz = 0.0f;
	this->tu = 0.0f;
	this->tv = 0.0f;
}

CUSTOMVERTEX::CUSTOMVERTEX(CUSTOMVERTEX& Custom_Vertex)
{
	this->x = Custom_Vertex.x;
	this->y = Custom_Vertex.y;
	this->z = Custom_Vertex.z;
	this->nx = Custom_Vertex.nx;
	this->ny = Custom_Vertex.ny;
	this->nz = Custom_Vertex.nz;
	this->tu = Custom_Vertex.tu;
	this->tv = Custom_Vertex.tv;
}

CUSTOMVERTEX::CUSTOMVERTEX(float X, float Y, float Z, float nX, float nY, float nZ, float tU, float tV)
{
	this->x = X;
	this->y = Y;
	this->z = Z;
	this->nx = nX;
	this->ny = nY;
	this->nz = nZ;
	this->tu = tU;
	this->tv = tV;
}