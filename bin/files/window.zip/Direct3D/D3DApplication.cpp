//-----------------------------------------------------------------------------------
#include "MRCD9.H"

//-----------------------------------------------------------------------------------
LRESULT CALLBACK MainWinProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
switch(msg)
  {
    case WM_DESTROY:
    {
      PostQuitMessage(0);
      return(0);
    }
  }
return DefWindowProc(hwnd, msg, wparam, lparam);
}

//-----------------------------------------------------------------------------------
int WINAPI WinMain( HINSTANCE hinstance, HINSTANCE hprevinstance, LPSTR lpcmdline, int ncmdshow)
{
MSG msg;
HWND hwnd = InitMainForm(hinstance, MainWinProc, "D3D", 800, 600);

ShowWindow( hwnd, SW_SHOWDEFAULT );
UpdateWindow( hwnd );
ZeroMemory( &msg, sizeof(msg));
while( msg.message!=WM_QUIT)
{
  if(PeekMessage( &msg, NULL,0,0,PM_REMOVE ))
  {
    TranslateMessage( &msg );
    DispatchMessage( &msg );
  }
  else
  {};
}
return 0;
}
//-----------------------------------------------------------------------------------