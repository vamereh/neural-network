#include "CAnimation.h" 

//---------------------------------------------------------------------------

CANIMATION::CANIMATION()
{
	for(unsigned short int iii=0; iii<50; iii++)
	{
		for(unsigned short int ii=0; ii<50; ii++)
		{
			this->morph_vertex[iii][ii] = NULL;
		};
	};

	this->fruit_vertex =  NULL;
	this->conect_vertex = NULL;
	this->kol_p = NULL;
}

CANIMATION::~CANIMATION()
{
	for(unsigned short int iii=0; iii<50; iii++)
	{
		for(unsigned short int ii=0; ii<50; ii++)
		{
			if (this->morph_vertex[iii][ii] != NULL) 
			{
				delete [] this->morph_vertex[iii][ii];
				this->morph_vertex[iii][ii] = NULL;
			};
		};
	};
	delete [] this->fruit_vertex;
	delete [] this->conect_vertex;
	delete [] this->kol_p;
}

void CANIMATION::LoadAnimationFF(char* passfile)
{     
	 //������ bma
     ifstream inf(passfile, ios::in | ios::binary);
    
     //��������� ��� ������
     inf.read((char*)&this->kol_vertex, 2);

     //��������� ���������� ����
     inf.read(this->texture_pass, 256);

     //��������� ��� ��������
     inf.read((char*)&this->kol_a, 2);

     //��������� ������������������
	 this->kol_p = new unsigned short int [this->kol_a];
     for (unsigned short int iii=0; iii<this->kol_a; iii++)
		inf.read((char*)&this->kol_p[iii], 2);
	 
	 //��������� �������
	 for (iii=0; iii<this->kol_a; iii++)
     {
	  for(unsigned short int ii=0; ii<=this->kol_p[iii]-1; ii++)
	  {	
			this->morph_vertex[iii][ii] = new CUSTOMVERTEX [this->kol_vertex];
			for(unsigned short int i=0; i<=this->kol_vertex-1; i++)
			{	
				inf.read((char*)&this->morph_vertex[iii][ii][i].x, 4);	 
				inf.read((char*)&this->morph_vertex[iii][ii][i].y, 4);	
				inf.read((char*)&this->morph_vertex[iii][ii][i].z, 4);	
				inf.read((char*)&this->morph_vertex[iii][ii][i].nx, 4);
				inf.read((char*)&this->morph_vertex[iii][ii][i].ny, 4);	
				inf.read((char*)&this->morph_vertex[iii][ii][i].nz, 4);
				inf.read((char*)&this->morph_vertex[iii][ii][i].tu, 4);
				inf.read((char*)&this->morph_vertex[iii][ii][i].tv, 4);
			};
	  };
	 };

	 //�������� ��������������� �������� ������ � ������
	 this->fruit_vertex = new CUSTOMVERTEX [this->kol_vertex];
	 this->conect_vertex = new CUSTOMVERTEX [this->kol_vertex];

	 //���������� ���������� ������� ������ ������������� ������
	 for (unsigned short int i=0; i<this->kol_vertex; i++)
	 {
		this->conect_vertex[i].x=this->morph_vertex[0][this->kol_p[0]-1][i].x;
	 	this->conect_vertex[i].y=this->morph_vertex[0][this->kol_p[0]-1][i].y;
	 	this->conect_vertex[i].z=this->morph_vertex[0][this->kol_p[0]-1][i].z;
	 	this->conect_vertex[i].nx=this->morph_vertex[0][this->kol_p[0]-1][i].nx;
	 	this->conect_vertex[i].ny=this->morph_vertex[0][this->kol_p[0]-1][i].ny;
	 	this->conect_vertex[i].nz=this->morph_vertex[0][this->kol_p[0]-1][i].nz;
	 	this->conect_vertex[i].tu=this->morph_vertex[0][this->kol_p[0]-1][i].tu;
	 	this->conect_vertex[i].tv=this->morph_vertex[0][this->kol_p[0]-1][i].tv;
	 };

	 //���������� ��������������� ����
	 this->GetMorphedMesh(0,0);

	 inf.close();
	 
}

void CANIMATION::GetMorphedMesh(unsigned short int nom_anim, float position)
{	
	//��������� ������������������
	float n=(position/(1.0f/this->kol_p[nom_anim]))-1;   
	int pos= (int)floorl(n);                       
	
	if (n>0) 
	{
		//��������� �������
	    float scalar=n-pos;                           

		for (unsigned short int i=0; i<=this->kol_vertex-1; i++)
		{
			this->fruit_vertex[i].x=(this->morph_vertex[nom_anim][pos][i].x * (1.0f-scalar)) + (this->morph_vertex[nom_anim][pos+1][i].x * scalar);
			this->fruit_vertex[i].y=(this->morph_vertex[nom_anim][pos][i].y * (1.0f-scalar)) + (this->morph_vertex[nom_anim][pos+1][i].y * scalar);
			this->fruit_vertex[i].z=(this->morph_vertex[nom_anim][pos][i].z * (1.0f-scalar)) + (this->morph_vertex[nom_anim][pos+1][i].z * scalar);

			this->fruit_vertex[i].nx=(this->morph_vertex[nom_anim][pos][i].nx * (1.0f-scalar)) + (this->morph_vertex[nom_anim][pos+1][i].nx * scalar);
			this->fruit_vertex[i].ny=(this->morph_vertex[nom_anim][pos][i].ny * (1.0f-scalar)) + (this->morph_vertex[nom_anim][pos+1][i].ny * scalar);
			this->fruit_vertex[i].nz=(this->morph_vertex[nom_anim][pos][i].nz * (1.0f-scalar)) + (this->morph_vertex[nom_anim][pos+1][i].nz * scalar);
        
			this->fruit_vertex[i].tu=this->morph_vertex[nom_anim][pos][i].tu;
			this->fruit_vertex[i].tv=this->morph_vertex[nom_anim][pos][i].tv;
		};
	}
	else
	{
		//��������� �������
		float scalar=1+n;                           

		for (unsigned short int i=0; i<=this->kol_vertex-1; i++)
		{
		this->fruit_vertex[i].x=(this->conect_vertex[i].x * (1.0f-scalar)) + (this->morph_vertex[nom_anim][0][i].x * scalar);
		this->fruit_vertex[i].y=(this->conect_vertex[i].y * (1.0f-scalar)) + (this->morph_vertex[nom_anim][0][i].y * scalar);
		this->fruit_vertex[i].z=(this->conect_vertex[i].z * (1.0f-scalar)) + (this->morph_vertex[nom_anim][0][i].z * scalar);

		this->fruit_vertex[i].nx=(this->conect_vertex[i].nx * (1.0f-scalar)) + (this->morph_vertex[nom_anim][0][i].nx * scalar);
		this->fruit_vertex[i].ny=(this->conect_vertex[i].ny * (1.0f-scalar)) + (this->morph_vertex[nom_anim][0][i].ny * scalar);
		this->fruit_vertex[i].nz=(this->conect_vertex[i].nz * (1.0f-scalar)) + (this->morph_vertex[nom_anim][0][i].nz * scalar);
        
		this->fruit_vertex[i].tu=this->conect_vertex[i].tu;
		this->fruit_vertex[i].tv=this->conect_vertex[i].tv;	
		};
	}
	
}

void CANIMATION::ReWriteConectMesh()
{
	for (unsigned short int i=0; i<this->kol_vertex; i++)
	 {
		this->conect_vertex[i].x=this->fruit_vertex[i].x;
	 	this->conect_vertex[i].y=this->fruit_vertex[i].y;
	 	this->conect_vertex[i].z=this->fruit_vertex[i].z;
	 	this->conect_vertex[i].nx=this->fruit_vertex[i].nx;
	 	this->conect_vertex[i].ny=this->fruit_vertex[i].ny;
	 	this->conect_vertex[i].nz=this->fruit_vertex[i].nz;
	 	this->conect_vertex[i].tu=this->fruit_vertex[i].tu;
	 	this->conect_vertex[i].tv=this->fruit_vertex[i].tv;
	 };
}

//--------------------------------------------------------------------------